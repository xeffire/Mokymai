public class Dvizenkliai {
    public static void main(String[] args) {
        // while
        int n = 10;
        while (n < 100) {
            System.out.print(n + " ");
            n += 2;
        }
        //for
        // for (int i = 10; i < 100; i += 2){
        //     System.out.print(i + " ");
        // }
    }
}
