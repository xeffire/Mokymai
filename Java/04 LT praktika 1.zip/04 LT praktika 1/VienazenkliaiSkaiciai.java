/**
 * VienazenkliaiSkaiciai
 */
public class VienazenkliaiSkaiciai {

    public static void main(String[] args) {
        //while
        int n = 0;
        while (n < 10) {
            System.out.print(n + " ");
            n++;
        }
        //for
        // for (int i = 0; i < 10; i++){
        //     System.out.print(i + " ");
        // }
    }
}