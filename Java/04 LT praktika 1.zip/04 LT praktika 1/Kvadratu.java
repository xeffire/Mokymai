
public class Kvadratu {
    public static void main(String[] args) {
        //while
        int n = 0;
        while (n < 10) {
            System.out.printf("%d - %d;%n", n, (int) Math.pow(n, 2));
            n++;
        }
        //for
        // for (int i = 0; i < 10; i++) {
        //     System.out.printf("%d - %d;%n", i, (int) Math.pow(i, 2));
        // }
    }
}
