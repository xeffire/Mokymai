
public class Vanduo {
    public static void main(String[] args) {
        Integer val = 18, diena, savaitė;
        diena = val * 24;
        savaitė = diena * 7;
        System.out.print("Per vieną valandą iš nesandaraus čiaupo išteką " + val + "L vandens. Per vieną dieną tai sudaro " + diena + "L vandens, o per savaitę - " + savaitė + "L!");
    }
}
